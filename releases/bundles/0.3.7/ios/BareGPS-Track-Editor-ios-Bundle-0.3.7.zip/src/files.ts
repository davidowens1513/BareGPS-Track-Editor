import { Capacitor, registerPlugin } from "@capacitor/core";
import { MAX_BYTES, exportGPX, type Track } from "./model";
export interface ImportFile {
  name: string;
  text: string;
}
export interface NativeFile {
  name: string;
  data: string;
}
export const NativeFiles = registerPlugin<{
  pick(): Promise<{ files: NativeFile[] }>;
  save(options: {
    name: string;
    data: string;
    mimeType?: string;
  }): Promise<{ saved: boolean }>;
  shareFile(options: { name: string; data: string }): Promise<void>;
  shareText(options: { title: string; text: string }): Promise<void>;
  pending(): Promise<{ files: NativeFile[]; errors?: string[] }>;
  addListener(
    event: "filesOpened",
    listener: () => void,
  ): Promise<{ remove(): Promise<void> }>;
}>("BareFiles");
export async function pickFiles(): Promise<ImportFile[]> {
  if (Capacitor.isNativePlatform()) {
    const { files } = await NativeFiles.pick();
    return files.map((f) => ({ name: f.name, text: decode(f.data) }));
  }
  return new Promise<ImportFile[]>((resolve, reject) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".gpx,application/gpx+xml,application/xml,text/xml";
    input.multiple = true;
    input.hidden = true;
    let reading = false;
    let settled = false;
    let focusTimer: ReturnType<typeof setTimeout> | undefined;
    const cleanup = () => {
      settled = true;
      clearTimeout(focusTimer);
      window.removeEventListener("focus", onFocus);
      input.remove();
    };
    const cancel = () => {
      if (settled || reading) return;
      cleanup();
      resolve([]);
    };
    const read = async () => {
      if (settled || reading) return;
      reading = true;
      clearTimeout(focusTimer);
      try {
        const files = Array.from(input.files ?? []);
        if (
          files.reduce((total, file) => total + file.size, 0) >
          30 * 1024 * 1024
        )
          throw new Error("Choose up to 30 MB of files at a time.");
        if (files.length > 20)
          throw new Error("Choose up to 20 GPX files at a time.");
        resolve(
          await Promise.all(
            files.map(async (file) => {
              if (file.size > MAX_BYTES)
                throw new Error(
                  `${file.name} is over 15 MB. Choose a smaller GPX file.`,
                );
              return { name: file.name, text: await file.text() };
            }),
          ),
        );
      } catch (e) {
        reject(e);
      } finally {
        cleanup();
      }
    };
    function onFocus() {
      // Some browsers return from the picker without a cancel/change event.
      // Allow the selection event to arrive before checking the input itself.
      clearTimeout(focusTimer);
      focusTimer = setTimeout(() => {
        if (input.files?.length) void read();
        else cancel();
      }, 1000);
    }
    input.addEventListener("cancel", cancel);
    input.addEventListener("change", read);
    window.addEventListener("focus", onFocus);
    document.body.append(input);
    try {
      input.click();
    } catch (e) {
      cleanup();
      reject(e);
    }
  });
}
export function decode(data: string): string {
  return new TextDecoder("utf-8", { fatal: true }).decode(
    Uint8Array.from(atob(data), (c) => c.charCodeAt(0)),
  );
}
export async function saveTrack(track: Track, filename = track.name) {
  const name =
    (filename
      .replace(/[<>:"/\\|?*\x00-\x1f]/g, "")
      .trim()
      .slice(0, 90) || "BareGPS track") + ".gpx";
  const xml = exportGPX(track);
  if (Capacitor.isNativePlatform()) {
    const bytes = new TextEncoder().encode(xml);
    let binary = "";
    for (let i = 0; i < bytes.length; i += 8192)
      binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
    return (await NativeFiles.save({ name, data: btoa(binary) })).saved;
  }
  const blob = new Blob([xml], { type: "application/gpx+xml" });
  if (typeof (window as any).showSaveFilePicker === "function") {
    const handle = await (
      window as unknown as {
        showSaveFilePicker(o: unknown): Promise<{
          createWritable(): Promise<{
            write(b: Blob): Promise<void>;
            close(): Promise<void>;
          }>;
        }>;
      }
    ).showSaveFilePicker({
      suggestedName: name,
      types: [
        {
          description: "GPX track",
          accept: { "application/gpx+xml": [".gpx"] },
        },
      ],
    });
    const writable = await handle.createWritable();
    await writable.write(blob);
    await writable.close();
  } else {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 30000);
  }
  return true;
}
export function isCancelled(error: unknown) {
  return (
    (error instanceof DOMException && error.name === "AbortError") ||
    (!!error &&
      typeof error === "object" &&
      "code" in error &&
      error.code === "CANCELLED")
  );
}

export async function shareRoutecard(
  title: string,
  text: string,
): Promise<boolean> {
  if (Capacitor.isNativePlatform()) {
    await NativeFiles.shareText({ title, text });
    return true;
  }
  if (typeof navigator.share !== "function") return false;
  await navigator.share({ title, text });
  return true;
}

export async function sharePDF(title: string, blob: Blob) {
  const name =
    (title
      .replace(/[<>:"/\\|?*\x00-\x1f]/g, "")
      .trim()
      .slice(0, 80) || "Route Card") + "-route-card.pdf";
  if (Capacitor.isNativePlatform()) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    for (let i = 0; i < bytes.length; i += 8192)
      binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
    await NativeFiles.shareFile({ name, data: btoa(binary) });
    return;
  }
  const file = new File([blob], name, { type: "application/pdf" });
  if (
    typeof navigator.share === "function" &&
    navigator.canShare?.({ files: [file] })
  ) {
    await navigator.share({ title, files: [file] });
    return;
  }
  const url = URL.createObjectURL(blob),
    link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

export async function saveData(
  name: string,
  text: string,
  type: string,
): Promise<boolean> {
  if (Capacitor.isNativePlatform()) {
    const bytes = new TextEncoder().encode(text);
    let binary = "";
    for (let i = 0; i < bytes.length; i += 8192)
      binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
    return (
      await NativeFiles.save({ name, data: btoa(binary), mimeType: type })
    ).saved;
  }
  const url = URL.createObjectURL(new Blob([text], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
  return true;
}
